exports.themeLocation = './app/wp-content/themes/dewpa-theme/';
exports.urlToPreview = 'http://vccw.test';

// Be SURE to update urlToPreview to YOUR domain and not mine.
// Be SURE to update themeLocation to YOUR theme folder name