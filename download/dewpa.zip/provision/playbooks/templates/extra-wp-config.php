define( 'JETPACK_DEV_DEBUG', {{ vccw.wp_debug }} );
define( 'WP_DEBUG', {{ vccw.wp_debug }} );
define( 'FORCE_SSL_ADMIN', {{ vccw.force_ssl_admin }} );
define( 'SAVEQUERIES', {{ vccw.savequeries }} );

{{ vccw.extra_wp_config }}
